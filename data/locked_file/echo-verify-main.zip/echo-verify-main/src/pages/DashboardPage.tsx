import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { getHistory, type HistoryEntry } from "@/services/api";
import { Search, ShieldCheck, ShieldX, UserPlus, Clock } from "lucide-react";

export default function DashboardPage() {
  const [userId, setUserId] = useState("");
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);

  const handleSearch = async () => {
    if (!userId.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const data = await getHistory(userId.trim());
      setHistory(data);
      setSearched(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load history");
      setHistory([]);
      setSearched(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container max-w-2xl py-12 px-4 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold font-display">Dashboard</h1>
          <p className="text-muted-foreground">View your authentication history and account details</p>
        </div>

        <div className="flex gap-2">
          <div className="flex-1 space-y-1">
            <Label htmlFor="searchId" className="sr-only">User ID</Label>
            <Input
              id="searchId"
              placeholder="Enter user ID to view history"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              className="font-mono"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
          </div>
          <Button onClick={handleSearch} disabled={loading || !userId.trim()}>
            {loading ? (
              <span className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
          </Button>
        </div>

        {error && (
          <p className="text-sm text-destructive text-center">{error}</p>
        )}

        {searched && history.length === 0 && !error && (
          <div className="text-center py-12 text-muted-foreground">
            <Clock className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>No history found for this user</p>
          </div>
        )}

        {history.length > 0 && (
          <div className="space-y-3">
            <h2 className="font-display font-semibold text-lg">Activity Log</h2>
            {history.map((entry) => (
              <div key={entry.id} className="flex items-center gap-4 p-4 rounded-lg border border-border bg-card">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  entry.action === "register" ? "bg-primary/10" : entry.success ? "bg-success/10" : "bg-destructive/10"
                }`}>
                  {entry.action === "register" ? (
                    <UserPlus className="w-5 h-5 text-primary" />
                  ) : entry.success ? (
                    <ShieldCheck className="w-5 h-5 text-success" />
                  ) : (
                    <ShieldX className="w-5 h-5 text-destructive" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm capitalize">{entry.action}</p>
                  <p className="text-xs text-muted-foreground">{new Date(entry.timestamp).toLocaleString()}</p>
                </div>
                {entry.similarityScore !== undefined && (
                  <span className="font-mono text-sm text-muted-foreground">{Math.round(entry.similarityScore * 100)}%</span>
                )}
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                  entry.success ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                }`}>
                  {entry.success ? "Success" : "Failed"}
                </span>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
