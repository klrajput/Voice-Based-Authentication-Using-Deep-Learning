import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { AudioRecorderPanel } from "@/components/AudioRecorderPanel";
import { registerVoice } from "@/services/api";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle, AlertCircle } from "lucide-react";

export default function RegisterPage() {
  const [userId, setUserId] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleSubmit = async (blob: Blob) => {
    if (!userId.trim()) {
      setResult({ success: false, message: "Please enter a User ID" });
      return;
    }
    setIsSubmitting(true);
    setResult(null);
    try {
      const res = await registerVoice(userId.trim(), blob);
      setResult({ success: res.success, message: res.message });
    } catch (err) {
      setResult({ success: false, message: err instanceof Error ? err.message : "Registration failed" });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container max-w-xl py-12 px-4 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold font-display">Register Your Voice</h1>
          <p className="text-muted-foreground">Create your unique voiceprint by recording a 6-second sample</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="userId">User ID</Label>
          <Input
            id="userId"
            placeholder="Enter a unique user ID"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="font-mono"
          />
        </div>

        <AudioRecorderPanel onSubmit={handleSubmit} isSubmitting={isSubmitting} submitLabel="Register Voice" />

        {result && (
          <div className={`flex items-center gap-3 p-4 rounded-lg border ${
            result.success ? "border-success/40 bg-success/5 text-success" : "border-destructive/40 bg-destructive/5 text-destructive"
          }`}>
            {result.success ? <CheckCircle className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
            <p className="text-sm">{result.message}</p>
          </div>
        )}

        <div className="p-4 rounded-lg bg-secondary/50 border border-border text-sm text-muted-foreground space-y-1">
          <p className="font-medium text-secondary-foreground">Tips for a good recording:</p>
          <ul className="list-disc list-inside space-y-0.5">
            <li>Find a quiet environment</li>
            <li>Speak naturally at a normal volume</li>
            <li>Hold your device 6-8 inches from your mouth</li>
            <li>Read a sentence or count numbers aloud</li>
          </ul>
        </div>
      </main>
    </div>
  );
}
