import { Link } from "react-router-dom";
import { Shield, Mic, UserPlus, Fingerprint, Lock, Waves } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/Navbar";
import heroWave from "@/assets/hero-wave.jpg";

const features = [
  { icon: Waves, title: "Voice Biometrics", desc: "Advanced SpeechBrain neural embeddings for speaker verification" },
  { icon: Fingerprint, title: "Unique Identity", desc: "Your voice is your password — no two voiceprints are alike" },
  { icon: Lock, title: "Secure & Private", desc: "Audio processed server-side and never stored in raw form" },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Hero */}
      <section className="relative flex-1 flex items-center justify-center gradient-hero px-4 py-20 overflow-hidden">
        <img src={heroWave} alt="" className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none" width={1920} height={800} />
        <div className="container max-w-4xl text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/5 text-primary text-sm font-mono">
            <Shield className="w-4 h-4" />
            Voice Authentication System
          </div>

          <h1 className="text-4xl sm:text-6xl font-bold font-display leading-tight">
            Authenticate with{" "}
            <span className="text-gradient">Your Voice</span>
          </h1>

          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            A secure, neural-network-powered voice verification system. Register your unique voiceprint
            and authenticate in seconds — no passwords needed.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button asChild size="lg" className="glow-primary text-base px-8">
              <Link to="/register">
                <UserPlus className="w-5 h-5 mr-2" /> Register Voice
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-base px-8">
              <Link to="/authenticate">
                <Mic className="w-5 h-5 mr-2" /> Verify Identity
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="container max-w-5xl">
          <h2 className="text-2xl font-bold font-display text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="p-6 rounded-xl gradient-card border border-border hover:border-primary/30 transition-colors">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-display font-semibold text-lg mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-6 px-4 text-center text-sm text-muted-foreground">
        VoiceGuard — Powered by SpeechBrain &amp; Neural Embeddings
      </footer>
    </div>
  );
}
