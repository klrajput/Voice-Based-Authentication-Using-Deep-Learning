import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { AudioRecorderPanel } from "@/components/AudioRecorderPanel";
import { authenticateVoice, type AuthenticateResponse } from "@/services/api";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShieldCheck, ShieldX } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function AuthenticatePage() {
  const [userId, setUserId] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<AuthenticateResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (blob: Blob) => {
    if (!userId.trim()) {
      setError("Please enter your User ID");
      return;
    }
    setIsSubmitting(true);
    setResult(null);
    setError(null);
    try {
      const res = await authenticateVoice(userId.trim(), blob);
      setResult(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const scorePercent = result ? Math.round(result.similarityScore * 100) : 0;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container max-w-xl py-12 px-4 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold font-display">Verify Your Identity</h1>
          <p className="text-muted-foreground">Record your voice to authenticate against your registered voiceprint</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="userId">User ID</Label>
          <Input
            id="userId"
            placeholder="Enter your registered user ID"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="font-mono"
          />
        </div>

        <AudioRecorderPanel onSubmit={handleSubmit} isSubmitting={isSubmitting} submitLabel="Verify Voice" />

        {error && (
          <div className="flex items-center gap-3 p-4 rounded-lg border border-destructive/40 bg-destructive/5 text-destructive">
            <ShieldX className="w-5 h-5 shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        {result && (
          <div className={`p-6 rounded-xl border space-y-4 ${
            result.authenticated
              ? "border-success/40 bg-success/5"
              : "border-destructive/40 bg-destructive/5"
          }`}>
            <div className="flex items-center gap-3">
              {result.authenticated ? (
                <ShieldCheck className="w-8 h-8 text-success" />
              ) : (
                <ShieldX className="w-8 h-8 text-destructive" />
              )}
              <div>
                <p className={`font-display font-bold text-lg ${result.authenticated ? "text-success" : "text-destructive"}`}>
                  {result.authenticated ? "Identity Verified" : "Verification Failed"}
                </p>
                <p className="text-sm text-muted-foreground">{result.message}</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Similarity Score</span>
                <span className="font-mono font-bold">{scorePercent}%</span>
              </div>
              <Progress value={scorePercent} className="h-2" />
              <p className="text-xs text-muted-foreground">Threshold: {Math.round(result.threshold * 100)}%</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
