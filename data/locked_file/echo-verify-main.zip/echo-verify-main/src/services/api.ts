const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

export interface RegisterResponse {
  success: boolean;
  message: string;
  userId: string;
}

export interface AuthenticateResponse {
  success: boolean;
  authenticated: boolean;
  similarityScore: number;
  threshold: number;
  message: string;
}

export interface HistoryEntry {
  id: string;
  timestamp: string;
  action: "register" | "authenticate";
  success: boolean;
  similarityScore?: number;
}

async function apiRequest<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({ message: "Request failed" }));
    throw new Error(body.message || `HTTP ${res.status}`);
  }
  return res.json();
}

export async function registerVoice(userId: string, audioBlob: Blob): Promise<RegisterResponse> {
  const form = new FormData();
  form.append("user_id", userId);
  form.append("audio", audioBlob, "recording.wav");
  return apiRequest<RegisterResponse>("/register", { method: "POST", body: form });
}

export async function authenticateVoice(userId: string, audioBlob: Blob): Promise<AuthenticateResponse> {
  const form = new FormData();
  form.append("user_id", userId);
  form.append("audio", audioBlob, "recording.wav");
  return apiRequest<AuthenticateResponse>("/authenticate", { method: "POST", body: form });
}

export async function getHistory(userId: string): Promise<HistoryEntry[]> {
  return apiRequest<HistoryEntry[]>(`/history?user_id=${encodeURIComponent(userId)}`);
}
