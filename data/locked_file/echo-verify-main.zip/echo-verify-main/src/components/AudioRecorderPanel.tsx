import { useAudioRecorder } from "@/hooks/useAudioRecorder";
import { WaveformVisualizer } from "./WaveformVisualizer";
import { RecordButton } from "./RecordButton";
import { RotateCcw, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AudioRecorderPanelProps {
  onSubmit: (blob: Blob) => void;
  isSubmitting?: boolean;
  submitLabel?: string;
}

export function AudioRecorderPanel({ onSubmit, isSubmitting = false, submitLabel = "Submit" }: AudioRecorderPanelProps) {
  const { isRecording, duration, audioBlob, audioUrl, analyserNode, error, volumeLevel, startRecording, stopRecording, resetRecording } = useAudioRecorder();

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex flex-col items-center gap-6 p-6 rounded-xl bg-card border border-border">
      <WaveformVisualizer analyserNode={analyserNode} isRecording={isRecording} />

      <div className="font-mono text-2xl text-foreground tabular-nums">
        {formatTime(duration)} <span className="text-muted-foreground text-sm">/ 0:06</span>
      </div>

      <div className="flex items-center gap-4">
        <RecordButton
          isRecording={isRecording}
          onStart={startRecording}
          onStop={stopRecording}
          volumeLevel={volumeLevel}
        />
      </div>

      {isRecording && (
        <p className="text-sm text-primary animate-pulse">Recording... speak naturally</p>
      )}

      {error && <p className="text-sm text-destructive">{error}</p>}

      {audioBlob && !isRecording && (
        <div className="flex flex-col items-center gap-4 w-full">
          <audio src={audioUrl || undefined} controls className="w-full max-w-sm" />
          <div className="flex gap-3">
            <Button variant="outline" onClick={resetRecording} disabled={isSubmitting}>
              <RotateCcw className="w-4 h-4 mr-2" /> Re-record
            </Button>
            <Button onClick={() => onSubmit(audioBlob)} disabled={isSubmitting}>
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                  Processing...
                </span>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" /> {submitLabel}
                </>
              )}
            </Button>
          </div>
        </div>
      )}

      {!isRecording && !audioBlob && !error && (
        <p className="text-sm text-muted-foreground">Click the microphone to start recording a 6-second voice sample</p>
      )}
    </div>
  );
}
