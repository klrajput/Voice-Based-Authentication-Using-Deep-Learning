import { Mic, Square } from "lucide-react";

interface RecordButtonProps {
  isRecording: boolean;
  onStart: () => void;
  onStop: () => void;
  volumeLevel?: number;
}

export function RecordButton({ isRecording, onStart, onStop, volumeLevel = 0 }: RecordButtonProps) {
  const scale = isRecording ? 1 + volumeLevel * 0.15 : 1;

  return (
    <button
      onClick={isRecording ? onStop : onStart}
      className={`relative flex items-center justify-center w-24 h-24 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background ${
        isRecording
          ? "bg-destructive animate-pulse-glow"
          : "bg-primary hover:brightness-110 glow-primary"
      }`}
      style={{ transform: `scale(${scale})` }}
      aria-label={isRecording ? "Stop recording" : "Start recording"}
    >
      {isRecording ? (
        <Square className="w-8 h-8 text-destructive-foreground" />
      ) : (
        <Mic className="w-8 h-8 text-primary-foreground" />
      )}
      {isRecording && (
        <span className="absolute inset-0 rounded-full border-2 border-destructive animate-ping opacity-30" />
      )}
    </button>
  );
}
