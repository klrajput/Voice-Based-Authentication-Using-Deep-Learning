import { Link, useLocation } from "react-router-dom";
import { Shield, Mic, UserPlus, LayoutDashboard } from "lucide-react";

const links = [
  { to: "/", label: "Home", icon: Shield },
  { to: "/register", label: "Register", icon: UserPlus },
  { to: "/authenticate", label: "Verify", icon: Mic },
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
];

export function Navbar() {
  const { pathname } = useLocation();

  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-display font-bold text-lg">
          <Shield className="w-6 h-6 text-primary" />
          <span className="text-gradient">VoiceGuard</span>
        </Link>
        <div className="flex items-center gap-1">
          {links.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                pathname === to
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{label}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
